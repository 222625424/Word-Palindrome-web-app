package za.ac.tut.web;

import java.io.IOException;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import za.ac.tut.bl.WordPalindromeLocal;

public class WordPalindromeServlet extends HttpServlet {

    @EJB
    WordPalindromeLocal wpl;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        HttpSession session = request.getSession();
        String word = request.getParameter("word");

        boolean isValid = wpl.isValid(word);
        String palindromeWord = wpl.isPalindrome(word);
        
        updateSession(session, isValid);
        
        request.setAttribute("word", word);
        request.setAttribute("is_valid", isValid);
        request.setAttribute("palindrome_word", palindromeWord);

        RequestDispatcher disp = request.getRequestDispatcher("word_palindrome_outcome.jsp");
        disp.forward(request, response);
    }

    private void updateSession(HttpSession session, boolean valid) {
        Integer wordCount = (Integer) session.getAttribute("word_count");
        if (wordCount == null) {
            wordCount = 0;
        }
        wordCount++;
        session.setAttribute("word_count", wordCount);
        
        if (valid) {
            Integer palindromeWordCount = (Integer) session.getAttribute("palindrome_word_count");
            if (palindromeWordCount == null) {
                palindromeWordCount = 0;
            }
            palindromeWordCount++;
            session.setAttribute("palindrome_word_count", palindromeWordCount);
        }
    }
}
