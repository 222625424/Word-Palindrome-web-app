/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/J2EE/EJB30/StatelessEjbClass.java to edit this template
 */
package za.ac.tut.bl;

import javax.ejb.Stateless;

/**
 *
 * @author THEKISO MTSHANYELO
 */
@Stateless
public class WordPalindrome implements WordPalindromeLocal {

   

    @Override
    public boolean isValid(String word) {
        boolean isValid = true;

        String lowWord = word.toLowerCase();

        int length =lowWord.length();
        for (int x = 0; x < length / 2 ; x++) {

            if (lowWord.charAt(x) != lowWord.charAt(length - x - 1)) {

                isValid = false;
            }
        }

        return isValid;
    }

    @Override
    public String isPalindrome(String word) {
        
        String reverseWord = "";
        
        for(int i = word.length() - 1; i >= 0 ; i--){
        
            reverseWord += word.charAt(i);
        }
        
        return reverseWord;
    }
    
    
}
